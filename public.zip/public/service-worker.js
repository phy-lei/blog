/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "20200415/index.html",
    "revision": "02177e01cb9805454fc0828b53c51801"
  },
  {
    "url": "20200526/index.html",
    "revision": "9fcb2113596368914fb1e403db47bb7c"
  },
  {
    "url": "20200528/index.html",
    "revision": "ba4188b5f864498d92997242af830a64"
  },
  {
    "url": "20200529/index.html",
    "revision": "c0bc6848072fdf68c00cd99c24ceb8b7"
  },
  {
    "url": "20200601/index.html",
    "revision": "d0112bbc1824e343c9c6633e473ef70a"
  },
  {
    "url": "20200602/index.html",
    "revision": "8e7f2f155970470ae73120fcfe1daf73"
  },
  {
    "url": "20200604/index.html",
    "revision": "4a1b92fd00599fbce596237e73584a8e"
  },
  {
    "url": "20200612/index.html",
    "revision": "e995cd395e9af3792dd3acdec23747f5"
  },
  {
    "url": "20200720/index.html",
    "revision": "c4819ab6dc0231b877b1165783771d3c"
  },
  {
    "url": "20200804/index.html",
    "revision": "5b9590caa444bb067976045417ab8864"
  },
  {
    "url": "20200812/index.html",
    "revision": "b74a71d47fecca8cb7aab677c34bc692"
  },
  {
    "url": "20201013/index.html",
    "revision": "0b1088af925a79e8cc768f1d6d125f10"
  },
  {
    "url": "20210112/index.html",
    "revision": "c3898e431c550e838eafb3d3259338ab"
  },
  {
    "url": "404.html",
    "revision": "72c9bcead4a88d555bb7f0a921b0e328"
  },
  {
    "url": "assets/121501/1.png",
    "revision": "c4bdcde64b3d33cbc8baec7e9d21d6f5"
  },
  {
    "url": "assets/200526/1.png",
    "revision": "126ac5ae3a114e3bec3b897d439cf3c7"
  },
  {
    "url": "assets/200526/2.png",
    "revision": "23dff91a7b5ac26d6580c2974b94bbca"
  },
  {
    "url": "assets/200526/3.png",
    "revision": "71821d824a4c76648b0a9ba01f6725ee"
  },
  {
    "url": "assets/200526/4.png",
    "revision": "a0d9ecf3271c8f8fbd7451fae743b268"
  },
  {
    "url": "assets/200526/5.png",
    "revision": "d01be8e7c3e3822c12af0dc06d443985"
  },
  {
    "url": "assets/css/0.styles.abf756cb.css",
    "revision": "e648d569c469da03dafef761338ed214"
  },
  {
    "url": "assets/img/home-bg.7b267d7c.jpg",
    "revision": "7b267d7ce30257a197aeeb29f365065b"
  },
  {
    "url": "assets/js/1.24adb6c4.js",
    "revision": "b65384c3408e83476c5c009718b2a55a"
  },
  {
    "url": "assets/js/10.9beb94d1.js",
    "revision": "b98ac66a5177665cd58fd2dbc39a9c2c"
  },
  {
    "url": "assets/js/11.bcc4433a.js",
    "revision": "42ebabdac185c33f56d7a0bd5af559af"
  },
  {
    "url": "assets/js/12.fae36277.js",
    "revision": "4ae65e508b80d82bbe08e942c4bbfef0"
  },
  {
    "url": "assets/js/13.81d3f27f.js",
    "revision": "bb452be72d8003671ccbb3929a8ed765"
  },
  {
    "url": "assets/js/14.3981894f.js",
    "revision": "71cd61b1c8b5f8fda368185fb1676d7b"
  },
  {
    "url": "assets/js/15.ec0655f9.js",
    "revision": "db6302dc3d2b2f254857b0364740fc64"
  },
  {
    "url": "assets/js/16.8b5681b3.js",
    "revision": "5af75498445b7f3fb934b43d73832532"
  },
  {
    "url": "assets/js/17.22b0b9c3.js",
    "revision": "af3f5eb5c933d70817b7a876555d0d0a"
  },
  {
    "url": "assets/js/18.955edf58.js",
    "revision": "83a824c098e2a101d149a7bdc218014d"
  },
  {
    "url": "assets/js/19.a723266d.js",
    "revision": "f0ead712aa00122e770f10277adc9c2d"
  },
  {
    "url": "assets/js/20.648f51f1.js",
    "revision": "6d683ed9f598e25c423eafdd17bf28e1"
  },
  {
    "url": "assets/js/21.221edad3.js",
    "revision": "591c6fee70cbdd40287917dbc9752bd3"
  },
  {
    "url": "assets/js/22.8c5185a9.js",
    "revision": "a40509002b27bed092e2120dfb5bfa57"
  },
  {
    "url": "assets/js/23.e6e62466.js",
    "revision": "2c2e463b4c434c1fa5a3547e6b0aebfd"
  },
  {
    "url": "assets/js/24.baedc6e5.js",
    "revision": "086a94ab27cef6b5e429be6f9683c53e"
  },
  {
    "url": "assets/js/25.949ebb61.js",
    "revision": "5b21aa8a1f56f5f2266ad1088859daa0"
  },
  {
    "url": "assets/js/26.846541f0.js",
    "revision": "02bce6348f976eebb6e81e936bf8ab8c"
  },
  {
    "url": "assets/js/27.0da90913.js",
    "revision": "029049e04ca3f65dfcbf499e69a868f9"
  },
  {
    "url": "assets/js/3.6bf1423a.js",
    "revision": "c3ef378f1f832e8ce7da6a039f16c47a"
  },
  {
    "url": "assets/js/4.dbf2144d.js",
    "revision": "ca3b52974629b10c249797412b536194"
  },
  {
    "url": "assets/js/5.7641bab5.js",
    "revision": "bda6d961d2f0dd76876c8a491aa2c4d6"
  },
  {
    "url": "assets/js/6.dd847cfd.js",
    "revision": "78224115f7d438c75a818e4d53b1708b"
  },
  {
    "url": "assets/js/7.c51aa669.js",
    "revision": "b238158d44413206de2445701dd13411"
  },
  {
    "url": "assets/js/8.3297022e.js",
    "revision": "e019a16cf5c062900daa8eaf8b72abbb"
  },
  {
    "url": "assets/js/9.3fc44e60.js",
    "revision": "907580ac1b1f8ba98b306daf54a80067"
  },
  {
    "url": "assets/js/app.c814298d.js",
    "revision": "b786081947e2f4552cf488662791965e"
  },
  {
    "url": "avatar.jpg",
    "revision": "d4dd2d543bfc95ffa6ce44ce1b75f709"
  },
  {
    "url": "avatar.png",
    "revision": "df4467759eab42a8de547f7fe386f68d"
  },
  {
    "url": "bg.jpg",
    "revision": "e06f1a51f4c146f1fd7d42ec4b6451ad"
  },
  {
    "url": "categories/article/index.html",
    "revision": "81d7362a2049c2f299f8a0c927528ffd"
  },
  {
    "url": "categories/css/index.html",
    "revision": "8560dec225b702e762f62bb56b256107"
  },
  {
    "url": "categories/index.html",
    "revision": "cc55e7df64359b4d692f160682724320"
  },
  {
    "url": "categories/linux/index.html",
    "revision": "abf39d53115f4413fe72604faca93874"
  },
  {
    "url": "categories/react/index.html",
    "revision": "d0c412cac78d3666665e2a5aa71240f2"
  },
  {
    "url": "categories/vuepress/index.html",
    "revision": "ccceaaa2e7ab8ba51bebaa720e919003"
  },
  {
    "url": "categories/前端的那些事儿/index.html",
    "revision": "0d138b58a51f7936d123badd05105a6d"
  },
  {
    "url": "categories/数据结构与算法/index.html",
    "revision": "c83fe9c8ca9159e60eb6e0730ef64026"
  },
  {
    "url": "hero.jpg",
    "revision": "c60b4e9b3a0454137d336d7fdf4a3bf7"
  },
  {
    "url": "icons/icon-128x128.png",
    "revision": "dc8ba44fcff9dd18aa935d23f6a49ed5"
  },
  {
    "url": "icons/icon-144x144.png",
    "revision": "681992f5b3649ffe525abb02eb3c619d"
  },
  {
    "url": "icons/icon-152x152.png",
    "revision": "e88f292f8c50879df390a697190537e5"
  },
  {
    "url": "icons/icon-192x192.png",
    "revision": "97f627f10205ac86868f9727ecb7c477"
  },
  {
    "url": "icons/icon-384x384.png",
    "revision": "231b6077415af6b017503e5b499cd90b"
  },
  {
    "url": "icons/icon-512x512.png",
    "revision": "771a697863a0bc92b4cffcbe66d25bc3"
  },
  {
    "url": "icons/icon-72x72.png",
    "revision": "1c10ea76fcd90a1c83aec949bb9dd254"
  },
  {
    "url": "icons/icon-96x96.png",
    "revision": "ed7b53a2f4596f15838eb88bd84c6f1c"
  },
  {
    "url": "icons/safari-pinned-tab.svg",
    "revision": "f358ba0595844b2acc7d02fc18cb56f4"
  },
  {
    "url": "index.html",
    "revision": "bed22ed0b2ded1d0a0c53f1ce19aded5"
  },
  {
    "url": "logo.png",
    "revision": "406370f8f120332c7a41611803a290b6"
  },
  {
    "url": "mine.jpg",
    "revision": "5ef1240314ed8707848ed856f43d7b13"
  },
  {
    "url": "tag/css/index.html",
    "revision": "a7fc62d668b3da853c79b79d845f6c11"
  },
  {
    "url": "tag/index.html",
    "revision": "40cf9e20529b09e659830bfe9f919418"
  },
  {
    "url": "tag/linux/index.html",
    "revision": "3f82c3250190645aef764e7ed56f8756"
  },
  {
    "url": "tag/react/index.html",
    "revision": "fe59d1dddb928df56b8da9fca46360b3"
  },
  {
    "url": "tag/tag3/index.html",
    "revision": "d00f49bed911aa790566577feb56481c"
  },
  {
    "url": "tag/tag4/index.html",
    "revision": "f8d37d0898f593bc5c7b2f1a26f69ca4"
  },
  {
    "url": "tag/vuepress/index.html",
    "revision": "7a82c0fa90bb8e7dfa7e26f9ade7e720"
  },
  {
    "url": "tag/前端的那些事儿/index.html",
    "revision": "f4b47e62cb5c0efddaba7c123df98ca0"
  },
  {
    "url": "tag/数据结构与算法/index.html",
    "revision": "17610b4ce03ab4926d5258c8fe22a2dc"
  },
  {
    "url": "timeline/index.html",
    "revision": "4ef940803e442fe4d0a0b1224026078a"
  },
  {
    "url": "views/article/2016/121501.html",
    "revision": "9e99d92c04e4c16db2a3d8eda07f0186"
  },
  {
    "url": "views/article/2017/092101.html",
    "revision": "e1cd970b603197618e574a5e4c829b1c"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
addEventListener('message', event => {
  const replyPort = event.ports[0]
  const message = event.data
  if (replyPort && message && message.type === 'skip-waiting') {
    event.waitUntil(
      self.skipWaiting().then(
        () => replyPort.postMessage({ error: null }),
        error => replyPort.postMessage({ error })
      )
    )
  }
})
