/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "404.html",
    "revision": "5899f4c5a6915dde2cf46d23547a89db"
  },
  {
    "url": "assets/121501/1.png",
    "revision": "c4bdcde64b3d33cbc8baec7e9d21d6f5"
  },
  {
    "url": "assets/200526/1.png",
    "revision": "126ac5ae3a114e3bec3b897d439cf3c7"
  },
  {
    "url": "assets/200526/2.png",
    "revision": "23dff91a7b5ac26d6580c2974b94bbca"
  },
  {
    "url": "assets/200526/3.png",
    "revision": "71821d824a4c76648b0a9ba01f6725ee"
  },
  {
    "url": "assets/200526/4.png",
    "revision": "a0d9ecf3271c8f8fbd7451fae743b268"
  },
  {
    "url": "assets/200526/5.png",
    "revision": "d01be8e7c3e3822c12af0dc06d443985"
  },
  {
    "url": "assets/css/0.styles.abf756cb.css",
    "revision": "e648d569c469da03dafef761338ed214"
  },
  {
    "url": "assets/img/home-bg.7b267d7c.jpg",
    "revision": "7b267d7ce30257a197aeeb29f365065b"
  },
  {
    "url": "assets/js/1.fe4bf35e.js",
    "revision": "589cdc1cde81d4fd91139349413d34ab"
  },
  {
    "url": "assets/js/10.46e772de.js",
    "revision": "a5b16d291cdd8d796fb2ae0e63ef6c4f"
  },
  {
    "url": "assets/js/11.bcc4433a.js",
    "revision": "42ebabdac185c33f56d7a0bd5af559af"
  },
  {
    "url": "assets/js/12.7ebd6532.js",
    "revision": "da63afe76d559408836193d6b5a64226"
  },
  {
    "url": "assets/js/13.5b56e977.js",
    "revision": "2f5a885302853969fb0cb63f72d4e0c9"
  },
  {
    "url": "assets/js/14.e71cfafd.js",
    "revision": "a507c97bbdcf707838b2bde7c7dfb5a7"
  },
  {
    "url": "assets/js/15.13baf169.js",
    "revision": "693abd4b26fa1a03dc2c67d706023944"
  },
  {
    "url": "assets/js/16.d10cb560.js",
    "revision": "cfdd4252b88093fc84b7f2248695ad31"
  },
  {
    "url": "assets/js/17.a6b70131.js",
    "revision": "ce1da493ef2ee0ad7f1556e32db13baf"
  },
  {
    "url": "assets/js/18.743dfb54.js",
    "revision": "1e97f5bdf1a30639c967c1ed0e36dfb6"
  },
  {
    "url": "assets/js/3.457ac1bb.js",
    "revision": "664f73e596f6f07f9e86b1d971e22619"
  },
  {
    "url": "assets/js/4.e2e5524c.js",
    "revision": "6e22356f695069d877e22c9a0c0ece50"
  },
  {
    "url": "assets/js/5.d8b16906.js",
    "revision": "10ea45a7aa668f9a1ffa09f6fbae92f4"
  },
  {
    "url": "assets/js/6.7db679e1.js",
    "revision": "ae7782d0ed83644d7a4e079452aee07e"
  },
  {
    "url": "assets/js/7.c51aa669.js",
    "revision": "b238158d44413206de2445701dd13411"
  },
  {
    "url": "assets/js/8.3297022e.js",
    "revision": "e019a16cf5c062900daa8eaf8b72abbb"
  },
  {
    "url": "assets/js/9.66502ce5.js",
    "revision": "5d0dae29b9d9368849fdadedcf73e83b"
  },
  {
    "url": "assets/js/app.89f04503.js",
    "revision": "644253f48cdee013cebe0debc69f49ba"
  },
  {
    "url": "avatar.jpg",
    "revision": "d4dd2d543bfc95ffa6ce44ce1b75f709"
  },
  {
    "url": "avatar.png",
    "revision": "df4467759eab42a8de547f7fe386f68d"
  },
  {
    "url": "bg.jpg",
    "revision": "e06f1a51f4c146f1fd7d42ec4b6451ad"
  },
  {
    "url": "categories/article/index.html",
    "revision": "776952cd940f3fc49fe6d6e3b78dc9f6"
  },
  {
    "url": "categories/index.html",
    "revision": "b2e2e21c6a5ec97177e563f402c136be"
  },
  {
    "url": "categories/noteDev/index.html",
    "revision": "78286af0fba015d73a341ea43f45b712"
  },
  {
    "url": "hero.jpg",
    "revision": "c60b4e9b3a0454137d336d7fdf4a3bf7"
  },
  {
    "url": "icons/icon-128x128.png",
    "revision": "dc8ba44fcff9dd18aa935d23f6a49ed5"
  },
  {
    "url": "icons/icon-144x144.png",
    "revision": "681992f5b3649ffe525abb02eb3c619d"
  },
  {
    "url": "icons/icon-152x152.png",
    "revision": "e88f292f8c50879df390a697190537e5"
  },
  {
    "url": "icons/icon-192x192.png",
    "revision": "97f627f10205ac86868f9727ecb7c477"
  },
  {
    "url": "icons/icon-384x384.png",
    "revision": "231b6077415af6b017503e5b499cd90b"
  },
  {
    "url": "icons/icon-512x512.png",
    "revision": "771a697863a0bc92b4cffcbe66d25bc3"
  },
  {
    "url": "icons/icon-72x72.png",
    "revision": "1c10ea76fcd90a1c83aec949bb9dd254"
  },
  {
    "url": "icons/icon-96x96.png",
    "revision": "ed7b53a2f4596f15838eb88bd84c6f1c"
  },
  {
    "url": "icons/safari-pinned-tab.svg",
    "revision": "f358ba0595844b2acc7d02fc18cb56f4"
  },
  {
    "url": "index.html",
    "revision": "1e1f1241d563d06c8055b4e2d443b272"
  },
  {
    "url": "logo.png",
    "revision": "406370f8f120332c7a41611803a290b6"
  },
  {
    "url": "mine.jpg",
    "revision": "5ef1240314ed8707848ed856f43d7b13"
  },
  {
    "url": "tag/index.html",
    "revision": "dbba01b12a195b89875af0e127b1a4ad"
  },
  {
    "url": "tag/react/index.html",
    "revision": "911bbf14f96d73ab13e8a305ba38d28f"
  },
  {
    "url": "tag/tag3/index.html",
    "revision": "363cd72522224d66ba9c9bd1c896c8fd"
  },
  {
    "url": "tag/tag4/index.html",
    "revision": "5787b6e913303700c7cd83bfcd4f2917"
  },
  {
    "url": "tag/vuepress/index.html",
    "revision": "2ab83a3f70d260aab9c4e26c8d470cc6"
  },
  {
    "url": "timeline/index.html",
    "revision": "1e21890d674c2f5accb756be7238d65e"
  },
  {
    "url": "views/article/2016/121501.html",
    "revision": "7c60e7e7e65aa63e23ea8847501b4b66"
  },
  {
    "url": "views/article/2017/092101.html",
    "revision": "68b621666c0d91a4e53c2e5c742b8115"
  },
  {
    "url": "views/noteDev/react/hook踩坑记.html",
    "revision": "e58975778aad331739bcac642a8cf004"
  },
  {
    "url": "views/noteDev/vuepress/200526.html",
    "revision": "4f4525091d8c7fb2011a370ad060249b"
  },
  {
    "url": "views/noteDev/vuepress/history模式.html",
    "revision": "d91fcaaa6a2f87bd7f6c3cbdb524d857"
  },
  {
    "url": "views/other/guide.html",
    "revision": "9ad960aa48008a952ee81dcabef7c2b9"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
addEventListener('message', event => {
  const replyPort = event.ports[0]
  const message = event.data
  if (replyPort && message && message.type === 'skip-waiting') {
    event.waitUntil(
      self.skipWaiting().then(
        () => replyPort.postMessage({ error: null }),
        error => replyPort.postMessage({ error })
      )
    )
  }
})
